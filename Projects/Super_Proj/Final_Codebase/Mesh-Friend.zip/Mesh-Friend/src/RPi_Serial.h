/*
 * RPi_Serial.h
 *
 *  Created on: Nov 16, 2019
 *      Author: poorn
 */

#ifndef RPI_SERIAL_H_
#define RPI_SERIAL_H_

#include "src/main.h"
#include "src/gpio.h"

#define RPi_UART	USART0
#define	RPi_Clock	cmuClock_USART0

#define UART0_Port			gpioPortA
#define UART0_Tx			0
#define UART0_Tx_Loc		0 << 8
#define UART0_Tx_En			1 << 1
#define UART0_Rx			5
#define UART0_Rx_Loc		4 << 0
#define UART0_Rx_En			1 << 0
#define	RPi_Port  	UART0_Port
#define RPi_Tx   	UART0_Tx
#define RPi_Tx_Loc	UART0_Tx_Loc
#define RPi_Tx_En	UART0_Tx_En
#define RPi_Rx_En	UART0_Rx_En
#define RPi_Rx   	UART0_Rx
#define RPi_Rx_Loc	UART0_Rx_Loc

#define RPi_Rx_Fixed_Msg_Len	5
#define RPi_Tx_Fixed_Msg_Len	8

void RPi_Init(void);
void RPi_Read_Byte(volatile uint8_t *address);
void RPi_Write_Byte(uint8_t data);
void Tx_to_RPi(uint8_t Incoming_State, uint8_t Node_No);
uint8_t Rx_from_RPi(uint16_t *Number);

#endif /* RPI_SERIAL_H_ */
