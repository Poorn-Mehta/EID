/*
 * RPi_Serial.c
 *
 *  Created on: Nov 16, 2019
 *      Author: poorn
 */


#include "src/RPi_Serial.h"

uint8_t RPi_Tx_Arr[150], RPi_Rx_Arr[150];

uint8_t UART_Rx_ISR_Buffer[5];

uint32_t j = 0;

const char On_Now_String[] = "ONNOW";
const char Off_Minute_String_Prefix = 'F';
const char FP_Update_String_Prefix[] = "FP";
const char No_Update_String[] = "NOUPD";

void RPi_Init(void)
{
	CMU_ClockSelectSet(cmuClock_HFPER, cmuSelect_HFXO);
	CMU_ClockEnable(cmuClock_HFPER, true);
	CMU_ClockEnable(cmuClock_GPIO, true);
	CMU_ClockEnable(RPi_Clock, true);

	GPIO_DriveStrengthSet(RPi_Port, gpioDriveStrengthStrongAlternateStrong);

	GPIO_PinModeSet(RPi_Port, RPi_Tx, gpioModePushPull, 1);
	GPIO_PinModeSet(RPi_Port, RPi_Rx, gpioModeInput, 0);

	const USART_InitAsync_TypeDef RPi_Init_Struct =
						  {
							usartDisable,           /* Enable RX/TX when initialization is complete. */
							0,                     /* Use current configured reference clock for configuring baud rate. */
							9600,                /* 9600 bits/s. */
							usartOVS16,            /* 16x oversampling. */
							usartDatabits8,        /* 8 data bits. */
							usartNoParity,         /* No parity. */
							usartStopbits1,        /* 1 stop bit. */
							false,                 /* Do not disable majority vote. */
							false,                 /* Not USART PRS input mode. */
							usartPrsRxCh0,         /* PRS channel 0. */
							false,                 /* Auto CS functionality enable/disable switch */
							0,                     /* Auto CS Hold cycles */
							0,                     /* Auto CS Setup cycles */
							usartHwFlowControlNone /* No HW flow control */
						  };

	USART_InitAsync(RPi_UART, &RPi_Init_Struct);

	RPi_UART->ROUTELOC0 = ((RPi_Tx_Loc) | (RPi_Rx_Loc));
	RPi_UART->ROUTEPEN = ((RPi_Tx_En) | (RPi_Rx_En));

	uint32_t int_clear;
	int_clear = USART_IntGet(RPi_UART);
	USART_IntClear(RPi_UART, int_clear);
	USART_IntEnable(RPi_UART, USART_IEN_RXDATAV);

//	NVIC_EnableIRQ(USART0_RX_IRQn);

	USART_Enable(RPi_UART, usartEnable);

	LCD_write("RPi Init Done", Passkey_Value);

}

void RPi_Read_Byte(volatile uint8_t *address)
{
	CORE_AtomicDisableIrq();
	*address = (volatile uint8_t)USART_Rx(RPi_UART);
	CORE_AtomicEnableIrq();
}

void RPi_Write_Byte(uint8_t data)
{
	CORE_AtomicDisableIrq();
	USART_Tx(RPi_UART, data);
	CORE_AtomicEnableIrq();
}

void Tx_to_RPi(uint8_t Incoming_State, uint8_t Node_No)
{

	memset(&RPi_Tx_Arr[0], 0, 150);

	switch(Incoming_State)
	{
		case LPN_Clear:
		{
			snprintf(RPi_Tx_Arr, RPi_Tx_Fixed_Msg_Len, "<CLR%02d>", Node_No);
			break;
		}

		case LPN_Alert:
		{
			snprintf(RPi_Tx_Arr, RPi_Tx_Fixed_Msg_Len, "<ALT%02d>", Node_No);
			break;
		}

		case LPN_Low_Batt:
		{
			snprintf(RPi_Tx_Arr, RPi_Tx_Fixed_Msg_Len, "<LOW%02d>", Node_No);
			break;
		}

		default:
		{
			snprintf(RPi_Tx_Arr, RPi_Tx_Fixed_Msg_Len, "<ERR%02d>", Node_No);
			break;
		}
	}

	uint8_t i;

	LCD_write(RPi_Tx_Arr, Mesh_Data);

	for(i = 0; i < RPi_Tx_Fixed_Msg_Len; i += 1)
	{
		RPi_Write_Byte(RPi_Tx_Arr[i]);
	}

//	LCD_write("String Sent", Flash_Data);

	RPi_Write_Byte(0);
}

uint8_t Rx_from_RPi(uint16_t *Number)
{
	uint8_t i;

	for(i = 0; i < RPi_Rx_Fixed_Msg_Len; i += 1)
	{
		//RPi_Read_Byte(&RPi_Rx_Arr[i]);
		RPi_Rx_Arr[i] = UART_Rx_ISR_Buffer[i];
	}

	LCD_write(RPi_Rx_Arr, Alarm_Value);

	if(strncmp(&RPi_Rx_Arr[0], &No_Update_String[0], 5) == 0)
	{
		*Number = 0;
		LCD_write("Det No Upd", Moisture_Row);
		return Resp_No_Update;
	}

	else if(strncmp(&RPi_Rx_Arr[0], &On_Now_String[0], 5) == 0)
	{
		*Number = 0;
		LCD_write("Det On Now", Moisture_Row);
		return Resp_On_Now;
	}

	else if(strncmp(&RPi_Rx_Arr[0], &FP_Update_String_Prefix[0], 2) == 0)
	{
		char FP_Min_Str[3];

		for(i = 0; i < 3; i += 1)
		{
			FP_Min_Str[i] = RPi_Rx_Arr[i + 2];
		}

		*Number = atoi(&FP_Min_Str[0]);
		LCD_write("Det FP Upd", Moisture_Row);
		return Resp_FP_Update;
	}

	else if(RPi_Rx_Arr[0] == Off_Minute_String_Prefix)
	{
		char Off_Min_Str[4];

		for(i = 0; i < 4; i += 1)
		{
			Off_Min_Str[i] = RPi_Rx_Arr[i + 1];
		}

		*Number = atoi(&Off_Min_Str[0]);
		LCD_write("Det Off Min", Moisture_Row);
		return Resp_Off_Min;
	}

	else
	{
		*Number = 0;
		LCD_write("Det NONE!!", Moisture_Row);
		return Resp_Error;
	}
}

//void RPi_Test(void)
//{
//	uint32_t i;
//	char msg[150];
//	uint8_t *tptr;
//
//	LCD_write("RPi Testing", Passkey_Value);
//
//	memset(&RPi_Tx_Arr[0], 0, 150);
//	snprintf(&msg[0], 150, "<Hello from SiLabs: %d\n>", j);
//	strncpy(&RPi_Tx_Arr[0], &msg[0], 150);
//
////	RPi_Tx_Arr[0] = '<';
//
//	for(i = 0; RPi_Tx_Arr[i] != 0; i ++)
//	{
//		RPi_Write_Byte(RPi_Tx_Arr[i]);
//	}
//	RPi_Write_Byte(0);
//
//	tptr = &RPi_Rx_Arr[0];
//
//	for(i = 0; i < 3; i ++)
//	{
//		RPi_Read_Byte(tptr++);
//	}
//
//	if((RPi_Rx_Arr[0] == '<') && (RPi_Rx_Arr[1] == 'A') && (RPi_Rx_Arr[2] == '>'))
//	{
//		LCD_write("Msg Successful", Flash_Data);
//	}
//	else
//	{
//		LCD_write("Msg Failure", Flash_Data);
//	}
//
//	j += 1;
//	LCD_write("RPi Test Done", Passkey_Value);
//}
