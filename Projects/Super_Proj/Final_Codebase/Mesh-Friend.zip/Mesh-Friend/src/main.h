#ifndef		__main_h__
#define 	__main_h__

//***********************************************************************************
// Include files
//***********************************************************************************

/* C Standard Library headers */
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/* Board headers */
#include "init_mcu.h"
#include "init_board.h"
#include "init_app.h"
#include "ble-configuration.h"
#include "board_features.h"
//#include "retargetserial.h"

/* Bluetooth stack headers */
#include "bg_types.h"
#include "native_gecko.h"
#include "gatt_db.h"
#include <gecko_configuration.h>
#include "mesh_generic_model_capi_types.h"
#include "mesh_lib.h"
#include <mesh_sizes.h>


/* Libraries containing default Gecko configuration values */
#include "em_emu.h"
#include "em_cmu.h"
#include "em_core.h"

#include "em_usart.h"

/* Device initialization header */
#include "hal-config.h"


/* Display Interface header */
#include "lcd_driver.h"

#endif

//***********************************************************************************
// defined files
//***********************************************************************************

#define FP_Timeout_Default_Min		1
#define Alert_Countdown_Max			4

#define Alert_Data			0x0001
#define Low_Batt_Data		0x0002
#define All_Good_Data		0x0003

#define Sign_Bit					15
#define Sign_Mask					(1 << Sign_Bit)
#define Turn_Off_Indication_Bit		7
#define Turn_Off_Mask				(1 << Turn_Off_Indication_Bit)
#define Turn_Off_Min_Mask			~(Turn_Off_Mask)
#define Turn_Off_Msg(x)				(x & Turn_Off_Min_Mask) | Turn_Off_Mask
#define Turn_On_Val					0x01

#define LPN_Clear		0
#define LPN_Alert		1
#define LPN_Low_Batt	2

#define Resp_No_Update		0
#define Resp_On_Now			1
#define Resp_Off_Min		2
#define Resp_FP_Update		3
#define Resp_Error			4

#define Soft_Timer_1s		32768
#define Periodic_Timer_s	5
#define Min_to_s			60
#define Min_to_Poll_Timer_Periods	(Min_to_s / Periodic_Timer_s)

//***********************************************************************************
// global variables
//***********************************************************************************

extern uint16_t Element_Index, Appkey_Index, Response;
extern uint8_t Trans_ID, conn_handle;

extern uint16_t New_Threshold, Old_Threshold, Publisher_Data, Publisher_Address;
extern uint8_t Alarm_Status, Old_Alarm_Status;

extern uint32_t Interrupt_Read;
extern uint8_t FP_Button;
extern char lcd_string[20];

extern uint32_t Off_Min_Counter;

extern uint8_t UART_Rx_ISR_Buffer[5];


//***********************************************************************************
// function prototypes
//***********************************************************************************
