/*
 * Custom_Grid_Eye.h
 *
 *  Created on: Sep 17, 2019
 *      Author: poorn
 */

#ifndef CUSTOM_GRID_EYE_H_
#define CUSTOM_GRID_EYE_H_

//***********************************************************************************
// Include files
//***********************************************************************************

#include "src/main.h"
#include "src/Custom_I2C0.h"

//***********************************************************************************
// defined files
//***********************************************************************************

#define Grid_Eye_Address			(uint8_t)0x69

#define LETIMER_Sleep_ms					100

#define Grid_Eye_Sleep_Multi_Factor			8
#define Grid_Eye_Setup_Multi_Factor			1
#define Grid_Eye_Active_Multi_Factor		1

#define Grid_Eye_Threshold					4

#define LETIMER_Start_Counter_Value			0
#define LETIMER_Wrap_Counter		(Grid_Eye_Sleep_Multi_Factor + Grid_Eye_Setup_Multi_Factor + Grid_Eye_Active_Multi_Factor) - 1

#define Grid_Eye_Sleep_to_Setup_Trigger		Grid_Eye_Sleep_Multi_Factor
#define Grid_Eye_Setup_to_Active_Trigger	Grid_Eye_Sleep_Multi_Factor + Grid_Eye_Setup_Multi_Factor
#define Grid_Eye_Active_to_Sleep_Trigger	LETIMER_Start_Counter_Value

#if (Board_Select == Dev_Kit_Mode)
	#define Grid_Eye_En_Port		gpioPortF
	#define Grid_Eye_En_Pin			(uint8_t)6
#else
	#define Grid_Eye_En_Port		gpioPortF // gpioPortD
	#define Grid_Eye_En_Pin			(uint8_t)3 // 10
#endif

#define Grid_Eye_Interrupt_High_Level_Low_Reg_Addr		(uint8_t)0x08
#define Grid_Eye_Interrupt_High_Level_High_Reg_Addr		(uint8_t)0x09
#define Grid_Eye_Interrupt_Low_Level_Low_Reg_Addr		(uint8_t)0x0A
#define Grid_Eye_Interrupt_Low_Level_High_Reg_Addr		(uint8_t)0x0B
#define Grid_Eye_Interrupt_Hysteresis_Low_Reg_Addr		(uint8_t)0x0C
#define Grid_Eye_Interrupt_Hysteresis_High_Reg_Addr		(uint8_t)0x0D
#define Grid_Eye_Thermistor_Temperature_Reg_Addr		(uint8_t)0x0E
#define Grid_Eye_Interrupt_Table_Start_Reg_Addr			(uint8_t)0x10
#define Grid_Eye_First_Pixel_Reg_Addr					(uint8_t)0x80

#define Grid_Eye_No_of_Interrupt_Vector_Registers		(uint8_t)8
#define Grid_Eye_No_of_Pixels							(uint8_t)128

#define Grid_Eye_Sensitivity				(float)0.25
#define Grid_Eye_Thermistor_Sensitivity		(float)0.0625

#define Grid_Eye_Temperatures_Low_Mask					(uint16_t)0x00FF
#define Grid_Eye_Temperatures_High_Mask					(uint16_t)0x0F00
#define Grid_Eye_Temperatures_Mask						(uint16_t)0x0FFF
#define Grid_Eye_Temperature_Sign_Mask					(uint16_t)0x0800

#define Grid_Eye_Interrupt_High_Limit			(float)511.75
#define Grid_Eye_Interrupt_Low_Limit			(float)-511.75
#define Grid_Eye_Interrupt_High_Temperature		(float)30
#define Grid_Eye_Interrupt_Low_Temperature		(float)10
#define Grid_Eye_Hysteresis						(float)0

#define Success_Return			(uint8_t)0
#define ERR_Temp_Out_of_Range	(uint8_t)1
#define ERR_Reg_Setting			(uint8_t)2
#define ERR_Temp_High_Config	(uint8_t)3
#define ERR_Temp_Low_Config		(uint8_t)4
#define ERR_Temp_Hyst_Config	(uint8_t)5

// Some macros
#define Grid_Eye_Power_Setup() 			GPIO_PinModeSet(Grid_Eye_En_Port, Grid_Eye_En_Pin, gpioModePushPull, 0)  //gpioModeDisabled
#define Grid_Eye_Power_Reset() 			GPIO_PinModeSet(Grid_Eye_En_Port, Grid_Eye_En_Pin, gpioModeDisabled, 0)
#define Grid_Eye_Power_On()				GPIO_PinOutSet(Grid_Eye_En_Port, Grid_Eye_En_Pin)
#define Grid_Eye_Power_Off()			GPIO_PinOutClear(Grid_Eye_En_Port, Grid_Eye_En_Pin)

#define Grid_Eye_Intrp_Ctrl_Reg_Addr			(uint8_t)0x03
#define Grid_Eye_Intrp_Ctrl_INTEN_Pos			(uint8_t)0
#define Grid_Eye_Intrp_Ctrl_INTEN_Mask			0x01 << Grid_Eye_Intrp_Ctrl_INTEN_Pos
#define Grid_Eye_Intrp_Ctrl_INTEN_Active(x)		*(uint8_t *)x |= Grid_Eye_Intrp_Ctrl_INTEN_Mask
#define Grid_Eye_Intrp_Ctrl_INTEN_Reactive(x)	*(uint8_t *)x &= Grid_Eye_Intrp_Ctrl_INTEN_Mask
#define Grid_Eye_Intrp_Ctrl_INTMOD_Pos			(uint8_t)1
#define Grid_Eye_Intrp_Ctrl_INTMOD_Mask			0x01 << Grid_Eye_Intrp_Ctrl_INTMOD_Pos
#define Grid_Eye_Intrp_Ctrl_INTMOD_Abs(x)		*(uint8_t *)x |= Grid_Eye_Intrp_Ctrl_INTMOD_Mask
#define Grid_Eye_Intrp_Ctrl_INTMOD_Diff(x)		*(uint8_t *)x &= ~Grid_Eye_Intrp_Ctrl_INTMOD_Mask


//***********************************************************************************
// global variables
//***********************************************************************************

//***********************************************************************************
// function prototypes
//***********************************************************************************

uint8_t Grid_Eye_Setup_Interrupts(void);
void Grid_Eye_Read_Interrupt_Table(void);
void Grid_Eye_Read_All_Pixels(void);
float Grid_Eye_Get_Thermistor_Temp_C(void);


#endif /* CUSTOM_GRID_EYE_H_ */
