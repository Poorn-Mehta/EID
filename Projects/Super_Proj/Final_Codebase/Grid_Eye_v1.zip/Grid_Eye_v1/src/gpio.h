#ifndef		__gpio_h__
#define 	__gpio_h__

//***********************************************************************************
// Include files
//***********************************************************************************
#include "main.h"
#include "em_gpio.h"

//***********************************************************************************
// defined files
//***********************************************************************************


#if (Board_Select == Dev_Kit_Mode)

//// LED0 pin is
#define	LED0_port  gpioPortF
#define LED0_pin   4
#define LED0_default	false 	// off

//// LED1 pin is
#define LED1_port  gpioPortF
#define LED1_pin   5
#define LED1_default	false	// off

#else

// LED
#define	LED_port  		gpioPortD
#define LED_pin   		13
#define LED_default		false

#endif

//  TODO: future values

//#define Button_Interrupt_Mask	0x40

#if (Board_Select == Dev_Kit_Mode)

#define Button1_port	gpioPortF
#define Button1_pin		7

//#define Button0_port	gpioPortF
//#define Button0_pin		6

#else

//#define Button_port		gpioPortB
//#define Button_pin		11

#define Button_port		gpioPortD
#define Button_pin		10

#endif

//***********************************************************************************
// global variables
//***********************************************************************************

extern volatile bool button0_read;
extern volatile bool button1_read;
extern volatile bool valid_button_press;

//***********************************************************************************
// function prototypes
//***********************************************************************************
void Button0_Init(void);
void Button1_Init(void);
void gpio_init(void);
#endif
