/*
 * mesh_friend.h
 *
 *  Created on: Nov 24, 2018
 *      Author: poorn
 */

#ifndef CUSTOM_MESH_LPN_H_
#define CUSTOM_MESH_LPN_H_

#include "src/main.h"

/** Timer Frequency used. */
#define TIMER_CLK_FREQ ((uint32)32768)
/** Convert msec to timer ticks. */
#define TIMER_MS_2_TIMERTICK(ms) ((TIMER_CLK_FREQ * ms) / 1000)

#define TIMER_ID_RESTART    		1
#define TIMER_ID_FACTORY_RESET  	2
#define TIMER_ID_Start_Regular		3
#define TIMER_ID_Friend_Find		4

#define Prov_Timeout_Seconds	10


///////////////// USEFUL

#define LPN_Conf_Success				0
#define ERR_LPN_Init_Failed				1
#define ERR_LPN_Config_Failed			2
#define Warn_LPN_No_Friend				3

uint8_t Custom_LPN_Init(uint8_t Min_Queue_Len, uint32_t Polling_Timeout_s);

#endif /* CUSTOM_MESH_LPN_H_ */
