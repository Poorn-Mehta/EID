#ifndef		__main_h__
#define 	__main_h__

//***********************************************************************************
// Include files
//***********************************************************************************

/* C Standard Library headers */
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

/* Board headers */
#include "init_mcu.h"
#include "init_board.h"
#include "init_app.h"
#include "ble-configuration.h"
#include "board_features.h"
#include "retargetserial.h"

/* Bluetooth stack headers */
#include "bg_types.h"
#include "native_gecko.h"
#include "gatt_db.h"
#include <gecko_configuration.h>
#include "mesh_generic_model_capi_types.h"
#include "mesh_lib.h"
#include <mesh_sizes.h>


/* Libraries containing default Gecko configuration values */
#include "em_emu.h"
#include "em_cmu.h"
#include "em_core.h"

#include "em_usart.h"

#include "em_letimer.h"

/* Device initialization header */
#include "hal-config.h"


/* Display Interface header */
#include "lcd_driver.h"

#endif

//***********************************************************************************
// defined files
//***********************************************************************************

#define Dev_Kit_Mode		0
#define Target_Board_Mode	1
#define Board_Select		Target_Board_Mode

#define Gen_Port						gpioPortD
#define Gen_Low_Batt_Indicator_Pin		(uint8_t)11
#define Gen_Fuse_Pin					(uint8_t)12
#define Gen_Low_Batt_LED_Pin			(uint8_t)13

#define Gen_Low_Batt_Indicator_Setup()		GPIO_PinModeSet(Gen_Port, Gen_Low_Batt_Indicator_Pin, gpioModeInputPull, false)

#define Gen_Fuse_Setup()			GPIO_PinModeSet(Gen_Port, Gen_Fuse_Pin, gpioModePushPull, false)
#define Gen_Fuse_Default()			GPIO_PinOutClear(Gen_Port, Gen_Fuse_Pin)
#define Gen_Fuse_Blow()				GPIO_PinOutSet(Gen_Port, Gen_Fuse_Pin)

#define Gen_Low_Batt_LED_Setup()			GPIO_PinModeSet(Gen_Port, Gen_Low_Batt_LED_Pin, gpioModePushPull, false)
#define Gen_Low_Batt_LED_Off()				GPIO_PinOutClear(Gen_Port, Gen_Low_Batt_LED_Pin)
#define Gen_Low_Batt_LED_On()				GPIO_PinOutSet(Gen_Port, Gen_Low_Batt_LED_Pin)

#define Low_Batt_Depletion_Timeout_s		30 // Just for demo purpose

#define Alert_Data			0x0001
#define Low_Batt_Data		0x0002
#define All_Good_Data		0x0003

#define Sign_Bit					15
#define Sign_Mask					(1 << Sign_Bit)
#define Turn_Off_Indication_Bit		7
#define Turn_Off_Mask				(1 << Turn_Off_Indication_Bit)
#define Turn_Off_Min_Mask			~(Turn_Off_Mask)
#define Turn_Off_Sec(x)				(x & Turn_Off_Min_Mask) * 60
#define Turn_On_Val					0x01

//#define Event_Si7021_Temperature_Read_Complete	3

//***********************************************************************************
// global variables
//***********************************************************************************

extern uint16_t Element_Index, Appkey_Index, Response;
extern uint8_t Trans_ID, conn_handle;

extern uint16_t New_Threshold, Old_Threshold, Publisher_Data, Publisher_Address;
extern uint8_t Alarm_Status, Old_Alarm_Status;

extern uint32_t Interrupt_Read;
extern uint8_t FP_Button;
extern char lcd_string[20];

//typedef enum {
//	Grid_Eye_OFF, //700 ms start
//	Grid_Eye_ON, //150 ms start
//	I2C_Comm //150 ms start
//} LETIMER_State;
//
//extern LETIMER_State Current_State;


//***********************************************************************************
// function prototypes
//***********************************************************************************
void Error_Indication(void);
