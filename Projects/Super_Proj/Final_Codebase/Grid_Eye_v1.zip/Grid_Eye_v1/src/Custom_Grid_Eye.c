/*
 * Custom_Grid_Eye.c
 *
 *  Created on: Sep 17, 2019
 *      Author: poorn
 */


//***********************************************************************************
// Include files
//***********************************************************************************
#include "src/Custom_Grid_Eye.h"

//***********************************************************************************
// Functions
//***********************************************************************************

static uint8_t Reg_Setting, Int_Temp_High_Part_Low, Int_Temp_High_Part_High, Int_Temp_Low_Part_Low;
static uint8_t Int_Temp_Low_Part_High, Int_Hysteresis_Part_Low, Int_Hysteresis_Part_High;
static uint16_t temp_var;
static float Temperature, Confirm;

uint8_t Grid_Eye_Setup_Interrupts(void)
{

// ---------->>>>>>>>>> Checking Requested Temperatures in Range or Not <<<<<<<<<<----------

	if((Grid_Eye_Interrupt_High_Temperature > Grid_Eye_Interrupt_High_Limit) || \
			(Grid_Eye_Interrupt_Low_Temperature < Grid_Eye_Interrupt_Low_Limit))
	{
#if (Board_Select == Dev_Kit_Mode)

		printf("Unable to process requested Interrupt Level\nMaximum and Minimum Supported are (in C) 511.75 and -511.75 respectively\n");
		printf("Interrupts won't be set");

#endif
		return ERR_Temp_Out_of_Range;
	}

// ---------->>>>>>>>>> Setting Interrupt Control Register <<<<<<<<<<----------

	Reg_Setting = 0;

	Grid_Eye_Intrp_Ctrl_INTEN_Active(&Reg_Setting);

	Grid_Eye_Intrp_Ctrl_INTMOD_Abs(&Reg_Setting);

	Custom_I2C0_Tx_Data[0] = Grid_Eye_Intrp_Ctrl_Reg_Addr;
	Custom_I2C0_Tx_Data[1] = Reg_Setting;

	Custom_I2C0_Write(Grid_Eye_Address, 2);

	Custom_I2C0_Tx_Data[0] = Grid_Eye_Intrp_Ctrl_Reg_Addr;

	Custom_I2C0_Write(Grid_Eye_Address, 1);
	Custom_I2C0_Read(Grid_Eye_Address, 1);

	if(Custom_I2C0_Rx_Data[0] != Reg_Setting)
	{
#if (Board_Select == Dev_Kit_Mode)
		printf("Error in writing Interrupt Control Reg\nGot: 0x%x Expected: 0x%x\n", Custom_I2C0_Rx_Data[0], \
														(Grid_Eye_Intrp_Ctrl_INTEN_Mask | Grid_Eye_Intrp_Ctrl_INTMOD_Mask));
#endif
		return ERR_Reg_Setting;
	}

// ---------->>>>>>>>>> Setting Interrupt High Level <<<<<<<<<<----------

	if(Grid_Eye_Interrupt_High_Temperature < 0)
	{
		Temperature = (Grid_Eye_Interrupt_High_Temperature * (float)-1) / Grid_Eye_Sensitivity;
		temp_var = (uint16_t)Temperature;
		temp_var ^= Grid_Eye_Temperatures_Mask;
		temp_var += 1;
	}
	else
	{
		Temperature = Grid_Eye_Interrupt_High_Temperature / Grid_Eye_Sensitivity;
		temp_var = (uint16_t)Temperature;
	}

	Int_Temp_High_Part_Low = temp_var & Grid_Eye_Temperatures_Low_Mask;
	Int_Temp_High_Part_High = (temp_var & Grid_Eye_Temperatures_High_Mask) >> 8;

	Custom_I2C0_Tx_Data[0] = Grid_Eye_Interrupt_High_Level_Low_Reg_Addr;
	Custom_I2C0_Tx_Data[1] = Int_Temp_High_Part_Low;
	Custom_I2C0_Write(Grid_Eye_Address, 2);

	Custom_I2C0_Tx_Data[0] = Grid_Eye_Interrupt_High_Level_High_Reg_Addr;
	Custom_I2C0_Tx_Data[1] = Int_Temp_High_Part_High;
	Custom_I2C0_Write(Grid_Eye_Address, 2);

	Custom_I2C0_Tx_Data[0] = Grid_Eye_Interrupt_High_Level_Low_Reg_Addr;
	Custom_I2C0_Write(Grid_Eye_Address, 1);
	Custom_I2C0_Read(Grid_Eye_Address, 2);

	temp_var = (Custom_I2C0_Rx_Data[1] << 8) + Custom_I2C0_Rx_Data[0];
	if((temp_var & Grid_Eye_Temperature_Sign_Mask) != 0)
	{
		temp_var ^= Grid_Eye_Temperatures_Mask;
		temp_var += 1;
		Confirm = ((float)temp_var * Grid_Eye_Sensitivity);
		Confirm *= (float)-1;
	}
	else
	{
		Confirm = ((float)temp_var * Grid_Eye_Sensitivity);
	}

	if(Confirm != Grid_Eye_Interrupt_High_Temperature)
	{
#if (Board_Select == Dev_Kit_Mode)
		printf("Error in writing Interrupt Low Level\nGot: %d Expected: %d\n", (int)Confirm, (int)Grid_Eye_Interrupt_High_Temperature);
#endif
		return ERR_Temp_High_Config;
	}

// ---------->>>>>>>>>> Setting Interrupt Low Level <<<<<<<<<<----------

	if(Grid_Eye_Interrupt_Low_Temperature < 0)
	{
		Temperature = (Grid_Eye_Interrupt_Low_Temperature * (float)-1) / Grid_Eye_Sensitivity;
		temp_var = (uint16_t)Temperature;
		temp_var ^= Grid_Eye_Temperatures_Mask;
		temp_var += 1;
	}
	else
	{
		Temperature = Grid_Eye_Interrupt_Low_Temperature / Grid_Eye_Sensitivity;
		temp_var = (uint16_t)Temperature;
		//tested good
	}

	Int_Temp_Low_Part_Low = temp_var & Grid_Eye_Temperatures_Low_Mask;
	Int_Temp_Low_Part_High = (temp_var & Grid_Eye_Temperatures_High_Mask) >> 8;

	Custom_I2C0_Tx_Data[0] = Grid_Eye_Interrupt_Low_Level_Low_Reg_Addr;
	Custom_I2C0_Tx_Data[1] = Int_Temp_Low_Part_Low;
	Custom_I2C0_Write(Grid_Eye_Address, 2);

	Custom_I2C0_Tx_Data[0] = Grid_Eye_Interrupt_Low_Level_High_Reg_Addr;
	Custom_I2C0_Tx_Data[1] = Int_Temp_Low_Part_High;
	Custom_I2C0_Write(Grid_Eye_Address, 2);

	Custom_I2C0_Tx_Data[0] = Grid_Eye_Interrupt_Low_Level_Low_Reg_Addr;
	Custom_I2C0_Write(Grid_Eye_Address, 1);
	Custom_I2C0_Read(Grid_Eye_Address, 2);

	temp_var = (Custom_I2C0_Rx_Data[1] << 8) + Custom_I2C0_Rx_Data[0];
	if((temp_var & Grid_Eye_Temperature_Sign_Mask) != 0x00)
	{
		temp_var ^= Grid_Eye_Temperatures_Mask;
		temp_var += 1;
		Confirm = ((float)temp_var * Grid_Eye_Sensitivity);
		Confirm *= (float)-1;
		//tested good
	}
	else
	{
		Confirm = ((float)temp_var * Grid_Eye_Sensitivity);
		//tested good - one time only though
	}

	if(Confirm != Grid_Eye_Interrupt_Low_Temperature)
	{
#if (Board_Select == Dev_Kit_Mode)
		printf("Error in writing Interrupt Low Level\nGot: %d Expected: %d\n", (int)Confirm, (int)Grid_Eye_Interrupt_Low_Temperature);
#endif
		//tested good? what the hell
		return ERR_Temp_Low_Config;
	}

// ---------->>>>>>>>>> Setting Interrupt Hysteresis Level <<<<<<<<<<----------

	if(Grid_Eye_Hysteresis < 0)
	{
		Temperature = (Grid_Eye_Hysteresis * (float)-1) / Grid_Eye_Sensitivity;
		temp_var = (uint16_t)Temperature;
		temp_var ^= Grid_Eye_Temperatures_Mask;
		temp_var += 1;
	}
	else
	{
		Temperature = Grid_Eye_Hysteresis / Grid_Eye_Sensitivity;
		temp_var = (uint16_t)Temperature;
	}

	Int_Hysteresis_Part_Low = temp_var & Grid_Eye_Temperatures_Low_Mask;
	Int_Hysteresis_Part_High = (temp_var & Grid_Eye_Temperatures_High_Mask) >> 8;

	Custom_I2C0_Tx_Data[0] = Grid_Eye_Interrupt_Hysteresis_Low_Reg_Addr;
	Custom_I2C0_Tx_Data[1] = Int_Hysteresis_Part_Low;
	Custom_I2C0_Write(Grid_Eye_Address, 2);

	Custom_I2C0_Tx_Data[0] = Grid_Eye_Interrupt_Hysteresis_High_Reg_Addr;
	Custom_I2C0_Tx_Data[1] = Int_Hysteresis_Part_High;
	Custom_I2C0_Write(Grid_Eye_Address, 2);

	Custom_I2C0_Tx_Data[0] = Grid_Eye_Interrupt_Hysteresis_Low_Reg_Addr;
	Custom_I2C0_Write(Grid_Eye_Address, 1);
	Custom_I2C0_Read(Grid_Eye_Address, 2);

	temp_var = (Custom_I2C0_Rx_Data[1] << 8) + Custom_I2C0_Rx_Data[0];
	if((temp_var & Grid_Eye_Temperature_Sign_Mask) != 0)
	{
		temp_var ^= Grid_Eye_Temperatures_Mask;
		temp_var += 1;
		Confirm = ((float)temp_var * Grid_Eye_Sensitivity);
		Confirm *= (float)-1;
	}
	else
	{
		Confirm = ((float)temp_var * Grid_Eye_Sensitivity);
	}

//	Grid_Eye_Test_On(); //NOT REACHING HERE

	if(Confirm != Grid_Eye_Hysteresis)
	{
#if (Board_Select == Dev_Kit_Mode)
		printf("Error in writing Interrupt Hysteresis Level\nGot: %d Expected: %d\n", (int)Confirm, (int)Grid_Eye_Hysteresis);
#endif
		return ERR_Temp_Low_Config;
	}

// ---------->>>>>>>>>> Everything Successful <<<<<<<<<<----------

#if (Board_Select == Dev_Kit_Mode)
	printf("\n****Everything Setup Successfully****\n");
#endif

	return Success_Return;
}

void Grid_Eye_Read_Interrupt_Table(void)
{
	Custom_I2C0_Tx_Data[0] = Grid_Eye_Interrupt_Table_Start_Reg_Addr;
	Custom_I2C0_Write(Grid_Eye_Address, 1);
	Custom_I2C0_Read(Grid_Eye_Address, Grid_Eye_No_of_Interrupt_Vector_Registers);
}

void Grid_Eye_Read_All_Pixels(void)
{
	Custom_I2C0_Tx_Data[0] = Grid_Eye_First_Pixel_Reg_Addr;
	Custom_I2C0_Write(Grid_Eye_Address, 1);
	Custom_I2C0_Read(Grid_Eye_Address, Grid_Eye_No_of_Pixels);
}


float Grid_Eye_Get_Thermistor_Temp_C(void)
{
	// Thermistor Register Low Address
	Custom_I2C0_Tx_Data[0] = Grid_Eye_Thermistor_Temperature_Reg_Addr;

	// Write command, and read data
	Custom_I2C0_Write(Grid_Eye_Address, 1);
	Custom_I2C0_Read(Grid_Eye_Address, 2);

	// Combine 2 bytes to form original data
	temp_var = ((Custom_I2C0_Rx_Data[1] << 8) + Custom_I2C0_Rx_Data[0]);

	if((temp_var & Grid_Eye_Temperature_Sign_Mask) != 0)
	{
		temp_var ^= Grid_Eye_Temperatures_Mask;
		temp_var += 1;
		Temperature = ((float)temp_var * Grid_Eye_Thermistor_Sensitivity);
		Temperature *= (float)-1;
	}
	else
	{
		Temperature = ((float)temp_var * Grid_Eye_Thermistor_Sensitivity);
	}

	return Temperature;
}
