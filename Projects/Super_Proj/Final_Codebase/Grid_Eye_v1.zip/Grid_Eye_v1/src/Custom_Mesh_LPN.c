/*
 * fingerprint.c
 *
 *  Created on: Dec 3, 2018
 *      Author: poorn
 */

#include "src/Custom_Mesh_LPN.h"

uint16_t Response;

uint8_t Custom_LPN_Init(uint8_t Min_Queue_Len, uint32_t Polling_Timeout_s)
{
	/* Initialize mesh lib */
	mesh_lib_init(malloc, free, 8);

	// Initialize LPN functionality.
	Response = gecko_cmd_mesh_lpn_init()->result;
	if(Response != 0)
	{
#if (Board_Select == Dev_Kit_Mode)
		printf("LPN Init failed (0x%x)\r\n", Response);
#endif
		return ERR_LPN_Init_Failed;
	}
	else
	{
#if (Board_Select == Dev_Kit_Mode)
		printf("LPN Init Success\r\n");
#endif
	}

	Response = gecko_cmd_mesh_lpn_configure(2, 5 * 1000)->result; //Min_Queue_Len, Polling_Timeout_s
	if(Response != 0)
	{
#if (Board_Select == Dev_Kit_Mode)
		printf("LPN Config Failed (0x%x)\r\n", Response);
#endif
		return ERR_LPN_Config_Failed;
	}
	else
	{
#if (Board_Select == Dev_Kit_Mode)
		printf("LPN Config Success\r\n");
#endif
	}

#if (Board_Select == Dev_Kit_Mode)
	printf("Trying to Find Friend...\r\n");
#endif

	Response = gecko_cmd_mesh_lpn_establish_friendship(0)->result;
	if(Response != 0)
	{
#if (Board_Select == Dev_Kit_Mode)
		printf("LPN Friendship failed (0x%x)\r\n", Response);
#endif
		return Warn_LPN_No_Friend;
	}
	else
	{
#if (Board_Select == Dev_Kit_Mode)
		printf("LPN Friendship Success\r\n");
#endif
	}

	return LPN_Conf_Success;
}

