/***********************************************************************************************//**
 * \file   main.c
 * \brief  Silicon Labs BT Mesh Empty Example Project
 *
 * This example demonstrates the bare minimum needed for a Blue Gecko BT Mesh C application.
 * The application starts unprovisioned Beaconing after boot
 ***************************************************************************************************
 * <b> (C) Copyright 2017 Silicon Labs, http://www.silabs.com</b>
 ***************************************************************************************************
 * This file is licensed under the Silabs License Agreement. See the file
 * "Silabs_License_Agreement.txt" for details. Before using this software for
 * any purpose, you must agree to the terms of that agreement.
 **************************************************************************************************/

/*****************************************************************************************************
 * Owner: Poorn Mehta (Poorn.Mehta@Colorado.EDU)
 * Date Last Modified:
 *****************************************************************************************************/


#include <src/Custom_Mesh_Init.h>
#include <src/Custom_Mesh_LPN.h>
#include "src/gpio.h"
#include "src/main.h"
#include "src/Custom_I2C0.h"
#include "src/Custom_Grid_Eye.h"
#include "src/Custom_Timer0.h"
#include "src/fingerprint.h"
#include "src/Custom_LETIMER0.h"


// Flag for indicating DFU Reset must be performed
uint8_t boot_to_dfu = 0;


static void handle_gecko_event(uint32_t evt_id, struct gecko_cmd_packet *evt);

bool mesh_bgapi_listener(struct gecko_cmd_packet *evt);

/** global variables */
uint16_t Element_Index = 0xffff;
uint16_t Appkey_Index = 0;
uint8_t Trans_ID = 0;
uint8_t conn_handle = 0xFF;      /* handle of the last opened LE connection */

char lcd_string[20];

static uint16 _my_address = 0;    /* Address of the Primary Element of the Node */
static uint8 num_connections = 0;     /* number of active Bluetooth connections */

uint16_t Andrew_Timeout = 0;
uint16_t Response;

volatile bool button0_read = false;
volatile bool button1_read = false;

uint16_t Publisher_Data, Publisher_Address;
uint8_t Alarm_Status = 0;
uint8_t Old_Alarm_Status = 0;

//uint8_t write;
uint16_t Moisture_Level;
uint16_t New_Threshold = 0;
uint16_t Old_Threshold = 0;
uint16_t Smoke_Level;


uint32_t Interrupt_Read;
uint8_t buzz_st = 0;

uint8_t FP_Button = 0;

uint8_t cntr = 0;
char print[3];

typedef enum {
	Batt_Charged,
	Batt_Low
} Battery_States;

Battery_States Current_Batt_Stat = Batt_Charged;

//uint8_t LPN_Off = 0;
//uint32_t LPN_Off_Sec_Counter = 0;
//uint32_t LPN_Off_Sec_Ref_Counter = 0;

uint32_t Low_Batt_Letimer_Counter = 0;

uint16_t Data_from_Friend = 0;

#define Event_LETIMER_Expired		1

uint8_t LETIMER_Counter;

void LETIMER0_IRQHandler(void)		// Letimer ISR, will execute after every 3 seconds
{
	CORE_AtomicDisableIrq();	// Nested interrupts not supported
	Interrupt_Read = LETIMER_IntGetEnabled(LETIMER0);	// Reading interrupt flag register
	LETIMER_IntClear(LETIMER0, LETIMTER_All_Interrupt_Mask);	// I like to clear all the interrupts so
	if(Interrupt_Read == LETIMER_IF_UF)	// Check for the specific interrupt
	{
		if(LETIMER_Counter < LETIMER_Wrap_Counter)
		{
			LETIMER_Counter += 1;
		}
		else
		{
			LETIMER_Counter = LETIMER_Start_Counter_Value;
		}
		gecko_external_signal(Event_LETIMER_Expired);
	}
	CORE_AtomicEnableIrq();		// Enable the interrupts again as ISR is ending
}
/*
 * Information about node is here
 * this is my primary node (central one for the project)
 */

#pragma GCC push_options
#pragma GCC optimize ("O0")

uint8_t Custom_Resp;
uint32_t i, j;
int32_t Grid_Eye_Pix_Arr[64];

// Move that pragma here

void set_device_name(bd_addr *pAddr)
{
	char name[20];

	// create unique device name using the last two bytes of the Bluetooth address
	sprintf(name, "Mesh LPN %x:%x", pAddr->addr[1], pAddr->addr[0]);

#if (Board_Select == Dev_Kit_Mode)
	printf("Device name: '%s'\r\n", name);
	// show device name on the LCD
	LCD_write(name, 2);
	LCD_write("", 5);
#endif

	Response = gecko_cmd_gatt_server_write_attribute_value(gattdb_device_name, 0, strlen(name), (uint8 *)name)->result;
	if(Response != 0)
	{
#if (Board_Select == Dev_Kit_Mode)
		printf("gecko_cmd_gatt_server_write_attribute_value() failed, code %x\r\n", Response);
#endif
	}
}

void initiate_factory_reset(void)
{
#if (Board_Select == Dev_Kit_Mode)
	printf("factory reset\r\n");
	LCD_write("\n***\nFACTORY RESET\n***", 5);
#endif

	/* if connection is open then close it before rebooting */
	if(conn_handle != 0xFF)
	{
		gecko_cmd_le_connection_close(conn_handle);
	}

	/* perform a factory reset by erasing PS storage. This removes all the keys and other settings
	that have been configured for this node */
	gecko_cmd_flash_ps_erase_all();
	gecko_cmd_hardware_set_soft_timer(2 * 32768, TIMER_ID_FACTORY_RESET, 1);
}

void Custom_Publish(int16_t Data)
{
	  struct mesh_generic_state custom_data;
	  errorcode_t response;

#if (Board_Select == Dev_Kit_Mode)
	  char temp_lcd[10];
#endif

	  custom_data.kind = mesh_generic_state_level;
	  custom_data.level.level = Data;


	  response = mesh_lib_generic_server_update(MESH_GENERIC_LEVEL_SERVER_MODEL_ID,
			  	  	  	  	  	  	  	  	  	  Element_Index,
												  &custom_data,
												  0,
												  0);

	  if(response != 0)
	  {
#if (Board_Select == Dev_Kit_Mode)
		  printf("Error while Updating 0x%x \n\r",response);
		  snprintf(temp_lcd, 10, "Err (MLib): %d",response);
		  LCD_write(temp_lcd, 5);
#endif
	  }
	  else
	  {
#if (Board_Select == Dev_Kit_Mode)
		  LCD_write("updt: 0x01", 5);
#endif

		  response = mesh_lib_generic_server_publish(MESH_GENERIC_LEVEL_SERVER_MODEL_ID,
				  	  	  	  	  	  	  	  	  	  Element_Index,
													  mesh_generic_state_level);
		  if(response != 0)
		  {
#if (Board_Select == Dev_Kit_Mode)
			  printf("Error while Publishing 0x%x \n\r",response);
			  snprintf(temp_lcd, 10, "Err (MLib): %d",response);
			  LCD_write(temp_lcd, 5);
#endif
		  }
		  else
		  {
#if (Board_Select == Dev_Kit_Mode)
			  printf("Publish Success \n\r");
			  snprintf(temp_lcd, 10, "publ: 0x01");
			  LCD_write(temp_lcd, 5);
#endif
		  }
	  }
}

void Custom_Alert_Check(void)
{
	uint8_t Threshold_Counter = 0;
	Grid_Eye_Read_Interrupt_Table();

#if (Board_Select == Dev_Kit_Mode)
	for(i = 0; i < 8; i ++)
	{
		for(j = 0; j < 8; j ++)
		{
			printf("%d ", (Custom_I2C0_Rx_Data[i] & (0x01 << j)) >> j);
		}
		printf("\n");
	}
	printf("\n\n");
#endif

	for(i = 0; i < 8; i ++)
	{
		if(Custom_I2C0_Rx_Data[i] != 0x00)
		{
			Threshold_Counter += 1;
		}
	}

	if(Threshold_Counter >= Grid_Eye_Threshold)
	{
#if (Board_Select == Dev_Kit_Mode)
			GPIO_PinOutSet(LED0_port, LED0_pin);
			GPIO_PinOutSet(LED1_port, LED1_pin);
			printf("**********ALERT**********\n");
#endif
			Custom_Publish(Alert_Data);
	}

	else
	{
#if (Board_Select == Dev_Kit_Mode)
		GPIO_PinOutClear(LED0_port, LED0_pin);
		GPIO_PinOutClear(LED1_port, LED1_pin);
		printf("NOTHING\n");
#endif
		Custom_Publish(All_Good_Data);
	}
}

int main()
{
	Mesh_Init();

	// Only enabling the clocks of I2C0. Structure and everything else pending.
	Custom_I2C0_Clock_Enable();

	//Blue_Gecko_Letimer_Init();

	gpio_init();

	Grid_Eye_Power_Setup();

	Gen_Low_Batt_Indicator_Setup();

	Gen_Fuse_Setup();
	Gen_Fuse_Default();

	Gen_Low_Batt_LED_Setup();


#if (Board_Select == Dev_Kit_Mode)
	//Configuring Debug monitor output
	RETARGET_SerialInit();


	//Configuring LCD
	LCD_init("");
	LCD_write("GRID EYE TEST", Mesh_Status);

#endif

	Blue_Gecko_Letimer_Init();

	while (1)
	{
		//Default code from empty mesh project
	    struct gecko_cmd_packet *evt = gecko_wait_event();
		bool pass = mesh_bgapi_listener(evt);
		if(pass)
		{
			handle_gecko_event(BGLIB_MSG_ID(evt->header), evt);
		}
	}

}

#pragma GCC pop_options //move it UP

static void handle_gecko_event(uint32_t evt_id, struct gecko_cmd_packet *evt)
{

	struct gecko_msg_mesh_node_provisioning_failed_evt_t  *prov_fail_evt;

	if (evt == NULL)
	{
		return;
	}

	switch (evt_id)
	{
		case gecko_evt_dfu_boot_id:
		{
			//gecko_cmd_le_gap_set_advertising_timing(0, 1000*adv_interval_ms/625, 1000*adv_interval_ms/625, 0, 0);
			gecko_cmd_le_gap_set_mode(2, 2);
			break;
		}

		case gecko_evt_system_boot_id:
		{
			//Check pushbutton state at startup. If it is held down then do factory reset
#if (Board_Select == Dev_Kit_Mode)
			if(GPIO_PinInGet(Button1_port, Button1_pin) == 0)
#else
			if(GPIO_PinInGet(Button_port, Button_pin) == 0)
#endif
			{
				initiate_factory_reset();
			}
			else
			{
				//Get the device address and set the name of the node
				struct gecko_msg_system_get_bt_address_rsp_t *pAddr = gecko_cmd_system_get_bt_address();
				set_device_name(&pAddr->address);

				//Intializing mesh stack with required out of band provisioning

				//Output authentication method, numeric value, size of 2 digits
				Response = gecko_cmd_mesh_node_init()->result;
				if(Response != 0)
				{
#if (Board_Select == Dev_Kit_Mode)
					printf("Node Failed\n\r");
					sprintf(lcd_string, "Error code: 0x%x\n\r", Response);
					LCD_write(lcd_string, Mesh_Status);
					printf("%s\n\r", lcd_string);
#endif
				}
			}
			break;
		}

		case gecko_evt_hardware_soft_timer_id:
		{
			//Handling software timers
			switch(evt->data.evt_hardware_soft_timer.handle)
			{
				//Factory reset
				case TIMER_ID_FACTORY_RESET:
				{
					//Resetting board
					gecko_cmd_system_reset(0);
					break;
				}

				case TIMER_ID_Start_Regular:
				{
#if (Board_Select == Dev_Kit_Mode)
					printf("\n\r\n\r*************NORMAL OPERATION START*************\n\r\n\r");
#endif

					Response  = gecko_cmd_hardware_set_soft_timer(2 * 32768, TIMER_ID_Friend_Find, 1)->result;
					if(Response != 0)
					{
#if (Board_Select == Dev_Kit_Mode)
						printf("Soft Timer Failure. Err %x\r\n", Response);
#endif
					}

					LETIMER_Counter = LETIMER_Start_Counter_Value;
					Set_Letimer_Clock_Prescaler(LETIMER_Sleep_ms);
					LETIMER_Enable(LETIMER0, true);

					break;
				}

				case TIMER_ID_Friend_Find:
				{
#if (Board_Select == Dev_Kit_Mode)
					printf("Trying to Find Friend...\r\n");
#endif
					Response = gecko_cmd_mesh_lpn_establish_friendship(0)->result;
					if(Response != 0)
					{
#if (Board_Select == Dev_Kit_Mode)
						printf("LPN Friendship failed (0x%x)\r\n", Response);
#endif
					}

					break;
				}

				default:
					break;
			}
			break;
		}

		case gecko_evt_system_external_signal_id:
		{
			uint32_t Event_Read = evt->data.evt_system_external_signal.extsignals;

			if(Event_Read == Event_LETIMER_Expired)
			{

				if(LETIMER_Counter == Grid_Eye_Sleep_to_Setup_Trigger)
				{
					if(Current_Batt_Stat == Batt_Charged)
					{
						Grid_Eye_Power_Setup();
						Grid_Eye_Power_On();
#if (Board_Select == Dev_Kit_Mode)
						LCD_write("SENSOR ON", Mesh_Status);
#endif
					}
				}

				else if(LETIMER_Counter == Grid_Eye_Setup_to_Active_Trigger)
				{
					if(Current_Batt_Stat == Batt_Charged)
					{
						Custom_I2C0_Init();
						Custom_Resp = Grid_Eye_Setup_Interrupts();
						if(Custom_Resp != Success_Return)
						{
#if (Board_Select == Dev_Kit_Mode)
							printf("Interrupt Setup Failed... Stopping\n\r");
							sprintf(lcd_string, "Error code: 0x%x\n\r", Custom_Resp);
							LCD_write(lcd_string, Mesh_Status);
							printf("%s\n\r", lcd_string);
							while(1); //TODO: Replace it with something better
#endif
						}
					}
				}

				else if(LETIMER_Counter == Grid_Eye_Active_to_Sleep_Trigger)
				{
					if(GPIO_PinInGet(Gen_Port, Gen_Low_Batt_Indicator_Pin) == 1)
					{
						Current_Batt_Stat = Batt_Low;
						Custom_Publish(Low_Batt_Data);
						Gen_Low_Batt_LED_On();
						Low_Batt_Letimer_Counter += 1;
					}
					else
					{
						Current_Batt_Stat = Batt_Charged;
						Gen_Low_Batt_LED_Off();
						Low_Batt_Letimer_Counter = 0;
					}

					if(Low_Batt_Letimer_Counter >= Low_Batt_Depletion_Timeout_s)
					{
						Gen_Fuse_Blow();
						while(1);
					}

					if(Current_Batt_Stat == Batt_Charged)
					{
						Custom_Alert_Check();
					}
					Grid_Eye_Power_Off();
					Custom_I2C0_Reset();
					Grid_Eye_Power_Reset();
#if (Board_Select == Dev_Kit_Mode)
					LCD_write("SENSOR OFF", Mesh_Status);
#endif
				}
			}

			break;
		}

//		case gecko_evt_mesh_generic_server_client_request_id:
//		{
////			uint8_t tmp;
////			tmp = evt->data.evt_mesh_generic_server_client_request.parameters.data[1];
////			tmp <<= 8;
////			Data_from_Friend = tmp	| evt->data.evt_mesh_generic_server_client_request.parameters.data[0];
//			Data_from_Friend = evt->data.evt_mesh_generic_server_client_request.parameters.data[0];
//
//			if((Data_from_Friend & Turn_Off_Mask) == 1)
//			{
//				LPN_Off = 1;
//				LPN_Off_Sec_Ref_Counter = Turn_Off_Sec(Data_from_Friend);
//			}
//
//			else if(Data_from_Friend == Turn_On_Val)
//			{
//				LPN_Off = 0;
//				LPN_Off_Sec_Counter = 0;
//				LPN_Off_Sec_Ref_Counter = 0;
//			}
//
//			break;
//		}

		//Node initialization
		case gecko_evt_mesh_node_initialized_id:
		{
			//One of the most important API calls - initializes client
			Response = gecko_cmd_mesh_generic_server_init()->result;
			if(Response != 0)
			{
#if (Board_Select == Dev_Kit_Mode)
				printf("Server Init Failed\n\r");
				printf("Error code: %x\n\r", Response);
#endif
			}
			else
			{
#if (Board_Select == Dev_Kit_Mode)
				printf("Node Successfully Initialized\r\n");
#endif
			}

			//Checking whether already provisioned or not
			struct gecko_msg_mesh_node_initialized_evt_t *pData = (struct gecko_msg_mesh_node_initialized_evt_t *)&(evt->data);

			if(pData->provisioned)
			{
#if (Board_Select == Dev_Kit_Mode)
				printf("Node is Provisioned. Address:%x, ivi:%ld\r\n", pData->address, pData->ivi);
				sprintf(lcd_string, "Provisioned - %d", pData->address);
				LCD_write(lcd_string, Provision_Status);
#endif
				_my_address = pData->address;
				Element_Index = 0;   // index of primary element is zero. This example has only one element.

				Custom_Resp = Custom_LPN_Init(2, 5); // min quelen, lpn poll
				if((Custom_Resp != LPN_Conf_Success) && (Custom_Resp != Warn_LPN_No_Friend))
				{
#if (Board_Select == Dev_Kit_Mode)
								printf("Low Power Mesh Node Setup Failed... Stopping\n\r");
								sprintf(lcd_string, "Error code: 0x%x\n\r", Custom_Resp);
								LCD_write(lcd_string, Mesh_Status);
								printf("%s\n\r", lcd_string);
								while(1); //TODO: Replace it with something better
#endif
				}

				Response = gecko_cmd_hardware_set_soft_timer(2 * 32768, TIMER_ID_Start_Regular, 1)->result; //TODO: Remove Magic Number
				if(Response != 0)
				{
#if (Board_Select == Dev_Kit_Mode)
					printf("Soft Timer Failure. Err %x\r\n", Response);
#endif
				}
			}
			else
			{
#if (Board_Select == Dev_Kit_Mode)
				printf("node is unprovisioned\r\n");
				LCD_write("unprovisioned", Provision_Status);
				printf("starting unprovisioned beaconing...\r\n");
#endif
				//          gecko_cmd_mesh_node_start_unprov_beaconing(0x3);   // enable ADV and GATT provisioning bearer
				gecko_cmd_mesh_node_start_unprov_beaconing(0x2);   // enable GATT provisioning bearer
			}
			break;
		}

		case gecko_evt_mesh_node_provisioning_started_id:
		{
#if (Board_Select == Dev_Kit_Mode)
			printf("Started provisioning\r\n");
			LCD_write("Provisioning...", Provision_Status);
#endif
			break;
		}

		case gecko_evt_mesh_node_provisioned_id:
		{
			_my_address = evt->data.evt_mesh_node_provisioned.address;
#if (Board_Select == Dev_Kit_Mode)
			printf("Node is Provisioned. Address:%x, ivi:%ld\r\n", _my_address, evt->data.evt_mesh_node_provisioned.iv_index);
			sprintf(lcd_string, "Provisioned - %d", _my_address);
			LCD_write(lcd_string, Provision_Status);
#endif
			Element_Index = 0;   // index of primary element is zero. This example has only one element.

			Custom_Resp = Custom_LPN_Init(2, 5); // min que len, lpn poll tout
			if((Custom_Resp != LPN_Conf_Success) && (Custom_Resp != Warn_LPN_No_Friend))
			{
#if (Board_Select == Dev_Kit_Mode)
				printf("Low Power Mesh Node Setup Failed... Stopping\n\r");
				sprintf(lcd_string, "Error code: 0x%x\n\r", Custom_Resp);
				LCD_write(lcd_string, Mesh_Status);
				printf("%s\n\r", lcd_string);
				while(1); //TODO: Replace it with something better
#endif
			}

			break;
		}

		case gecko_evt_mesh_node_provisioning_failed_id:
		{
			prov_fail_evt = (struct gecko_msg_mesh_node_provisioning_failed_evt_t  *)&(evt->data);
#if (Board_Select == Dev_Kit_Mode)
			printf("Node Provisioning Failed... Stopping, Code %x\r\n", prov_fail_evt->result);
			LCD_write("Prov Failed", Provision_Status);
			while(1); //TODO: Replace it with something better
#endif
			/* start a one-shot timer that will trigger soft reset after small delay */
//			gecko_cmd_hardware_set_soft_timer(2 * 32768, TIMER_ID_FACTORY_RESET, 1);
			break;
		}

		//Empirically it was found out that this event is the one which take place
		//After the provisioner has finished each and every setting. So after a fixed delay, starting regular functionality.
		case gecko_evt_mesh_node_model_config_changed_id:
		{
#if (Board_Select == Dev_Kit_Mode)
			printf("Model Config Changed\r\n");
#endif
			Response = gecko_cmd_hardware_set_soft_timer(10 * 32768, TIMER_ID_Start_Regular, 1)->result; //TODO: Remove Magic Number
			if(Response != 0)
			{
#if (Board_Select == Dev_Kit_Mode)
				printf("Soft Timer Failure. Err %x\r\n", Response);
#endif
			}
			break;
		}

		case gecko_evt_le_connection_opened_id:
		{
#if (Board_Select == Dev_Kit_Mode)
			printf("Connection Opened Event\r\n");
#endif
			num_connections++;
			conn_handle = evt->data.evt_le_connection_opened.connection;
			break;
		}

		case gecko_evt_le_connection_parameters_id:
		{
#if (Board_Select == Dev_Kit_Mode)
			printf("Connection Parameters Event\r\n");
#endif
			break;
		}

		case gecko_evt_le_connection_closed_id:
		{
			/* Check if need to boot to dfu mode */
			if(boot_to_dfu)
			{
				/* Enter to DFU OTA mode */
				gecko_cmd_system_reset(2);
			}
#if (Board_Select == Dev_Kit_Mode)
			printf("Connection Closed Event, Reason 0x%x\r\n", evt->data.evt_le_connection_closed.reason);
			if(num_connections > 0)
			{
				if(--num_connections == 0)
				{
				//LCD_write("", 3);// TODO: DI_ROW_CONNECTION
				}
			}
#endif
			conn_handle = 0xFF;
			break;
		}



	    case gecko_evt_mesh_lpn_friendship_established_id:
	    {
#if (Board_Select == Dev_Kit_Mode)
		  printf("Friendship Established\r\n");
		  LCD_write("LPN", Friendship_Status);
#endif
		  break;
	    }

	    case gecko_evt_mesh_lpn_friendship_failed_id:
	    {
#if (Board_Select == Dev_Kit_Mode)
			printf("Friendship Failed\r\n");
			LCD_write("No Friend", Friendship_Status);
#endif
			Response  = gecko_cmd_hardware_set_soft_timer(2 * 32768, TIMER_ID_Friend_Find, 1)->result;
			if(Response != 0)
			{
#if (Board_Select == Dev_Kit_Mode)
				printf("Soft Timer Failure. Err %x\r\n", Response);
#endif
			}
			break;
	    }

	    case gecko_evt_mesh_lpn_friendship_terminated_id:
	    {
#if (Board_Select == Dev_Kit_Mode)
			printf("Friendship Terminated\r\n");
			LCD_write("No Friend", Friendship_Status);
#endif
			Response  = gecko_cmd_hardware_set_soft_timer(2 * 32768, TIMER_ID_Friend_Find, 1)->result;
			if(Response != 0)
			{
#if (Board_Select == Dev_Kit_Mode)
				printf("Soft Timer Failure. Err %x\r\n", Response);
#endif
			}
			break;
	    }





//		case gecko_evt_mesh_node_reset_id:
//		{
//#if (Board_Select == Dev_Kit_Mode)
//			printf("evt gecko_evt_mesh_node_reset_id\r\n");
//#endif
//			initiate_factory_reset();
//			break;
//		}

		case gecko_evt_gatt_server_user_write_request_id:
		{
			if(evt->data.evt_gatt_server_user_write_request.characteristic == gattdb_ota_control)
			{
				/* Set flag to enter to OTA mode */
				boot_to_dfu = 1;
				/* Send response to Write Request */
				gecko_cmd_gatt_server_send_user_write_response(
				evt->data.evt_gatt_server_user_write_request.connection,
				gattdb_ota_control,
				bg_err_success);

				/* Close connection to enter to DFU OTA mode */
				gecko_cmd_le_connection_close(evt->data.evt_gatt_server_user_write_request.connection);
			}
			break;
		}

		default:
			break;
	}
}
